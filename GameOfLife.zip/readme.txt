Pliki nagłówkowe - GameBoard i GameBoardWalc mają konstruktory o które pytałem, w {} wpisałem couta, żeby widzieć który konstruktor się uruchamia

W sumie tylko main.cpp GameBoard.hpp i GameBoardWalc.hpp są potrzebne, reszte wysyłam, żeby się kompilowało


Wywołanie po uruchomieniu:
Parent - konstruktor parenta
Parent - kontruktor parenta
Plansza Walc - konstruktor childa1
Parent - kontruktor parenta
Plansza Donut - kontruktor childa2


Nie wiem gdzie dodać destruktory, żeby nie przeciążyć potem pamięci (przez nieskończoność) - dodanie na końcu wcale go nie uruchamia (dodałem std::cout << "Destruktor parent";)

Destruktor wirtualny nic nie zmienia.