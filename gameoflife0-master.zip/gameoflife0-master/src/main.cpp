#include "GameBoardBasic.hpp"
#include "GameBoardCylinder.hpp"
#include "GameBoardTorus.hpp"
#include "AlwaysNextTurn.hpp"
#include "UserCommands.hpp"
#include <iostream>
#include <string>

int main() {
//
    AlwaysNextTurn auto_command_source;
    UserCommands user_command_source;
    GameBoardBasic gamebb{40,40};
    GameBoardCylinder gamebc{40, 40};
    GameBoardTorus gamebt{40, 40};

    std::string wybrana_plansza;
    std::cout << "Wybierz typ planszy [basic, cylinder, torus]: ";
    std::cin >> wybrana_plansza;


    std::string wybrany_tryb;
    std::cout << "Wybierz źródło komend [user, auto]: ";
    std::cin >> wybrany_tryb;

    if (wybrana_plansza == "normal") {
        if (wybrany_tryb == "user")
            gamebb.play(user_command_source);
        else if (wybrany_tryb == "auto")
            gamebb.play(auto_command_source);
    }
    else if (wybrana_plansza == "cylinder") {
        if (wybrany_tryb == "user")
            gamebc.play(user_command_source);
        else if (wybrany_tryb == "auto")
            gamebc.play(auto_command_source);
    }
    else if (wybrana_plansza == "torus") {
        if (wybrany_tryb == "user")
            gamebt.play(user_command_source);
        else if (wybrany_tryb == "auto")
            gamebt.play(auto_command_source);
    }
    else {
        std::cout << "Niewłaściwy typ planszy";
    }

    return 0;
}