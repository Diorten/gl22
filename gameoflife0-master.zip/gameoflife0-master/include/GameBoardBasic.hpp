//
// Created by najma on 26.04.2022.
//
#pragma once
#include <vector>
#include <iostream>
#include "CommandSource.hpp"

struct cell
{
    bool isAlive;
    bool shouldChangeNextGen;
};
class GameBoardBasic
{
    //int width;
    //int height;

public:

    int width = 40;
    int height = 40;

    std::vector<std::vector<cell>> board;

    GameBoardBasic(int width = 40, int height = 40) : width{width}, height{height}, board(width, std::vector<cell>(height, cell{false, false})){reviveRandomCellsAtBegining();}


    void display() const;

    virtual void reviveRandomCellsAtBegining();
    void reviveCellsByIndex();

    int getBoardWidth();
    int getBoardHeight();

    virtual int countCellsAround(int row, int col);

    virtual void shouldChangeStatus(int row, int col);

    virtual void changeStatus(int row, int col);

    virtual char getSign(int row, int col) const;

    bool checkStatus(int row, int col) const;

    virtual void changeCellStatus(int row, int col);

    void play(CommandSource& c_source);

    ~GameBoardBasic() {std::cout << "Destruktor parent";};

};